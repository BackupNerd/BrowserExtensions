/**
 * Cove Error Search Links — Options / Settings page
 * Manages AI search targets, prompt context, exclusions, and click behavior.
 */

// ── Storage keys ──────────────────────────────────────────────────────────
const STORAGE_KEY    = "aiTargets";
const PROMPT_KEY     = "aiPrompt";
const VENDOR_KEY     = "aiVendors";
const EXCLUSIONS_KEY = "aiExclusions";
const BEHAVIOR_KEY   = "clickBehavior";

// ── Defaults ──────────────────────────────────────────────────────────────
const DEFAULT_BEHAVIOR  = "icons";

const DEFAULT_TARGETS = [
  { name: "Google AI Mode", url: "https://www.google.com/search?udm=50&q=", isDefault: true  },
  { name: "Perplexity AI",  url: "https://www.perplexity.ai/search?q=",      isDefault: false },
  { name: "Brave Search",   url: "https://search.brave.com/search?q=",       isDefault: false },
  { name: "Bing",           url: "https://www.bing.com/search?q=",            isDefault: false },
  { name: "",               url: "",                                          isDefault: false },
  { name: "",               url: "",                                          isDefault: false },
];

const DEFAULT_PROMPT     = { terms: "Troubleshoot Cove Data Protection with the following error.", enabled: true };
const DEFAULT_VENDORS    = { terms: "Find similar resolution for third party backup products like Veeam, Acronis and others.", enabled: true };
const DEFAULT_EXCLUSIONS = "withcove.com";

// ── Helpers ───────────────────────────────────────────────────────────────
function escHtml(s) {
  return (s || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

function showSaved() {
  const msg = document.getElementById("statusMsg");
  msg.classList.add("show");
  setTimeout(() => msg.classList.remove("show"), 2200);
}

// ── Behavior card highlight ───────────────────────────────────────────────
function updateBehaviorHighlight() {
  const selected = document.querySelector("input[name='clickBehavior']:checked");
  document.querySelectorAll(".behavior-option").forEach(el => el.classList.remove("selected"));
  if (selected) {
    const wrap = selected.closest(".behavior-option");
    if (wrap) wrap.classList.add("selected");
  }
}

// ── Prompt preview ────────────────────────────────────────────────────────
function updatePreview() {
  const pTerms   = document.getElementById("promptTerms").value.trim();
  const pEnabled = document.getElementById("promptEnabled").checked;
  const vTerms   = document.getElementById("vendorTerms").value.trim();
  const vEnabled = document.getElementById("vendorEnabled").checked;
  const preview  = document.getElementById("promptPreview");

  const parts = [];
  if (pEnabled && pTerms) parts.push(pTerms);
  parts.push("\u2039error text\u203a");
  if (vEnabled && vTerms) parts.push(vTerms);

  preview.textContent = parts.length > 1
    ? `Preview: "${parts.join(" ")}"`
    : "No context — only the raw error text will be sent.";
}

// ── Target rows ───────────────────────────────────────────────────────────
function buildRows(targets) {
  const container = document.getElementById("targetRows");
  container.innerHTML = "";

  targets.forEach((t, i) => {
    const row = document.createElement("div");
    row.className = "target-row";
    row.innerHTML = `
      <span class="row-num">${i + 1}</span>
      <input type="text" class="t-name" placeholder="Name (e.g. Perplexity)" value="${escHtml(t.name)}" />
      <input type="text" class="t-url"  placeholder="URL prefix ending with q=" value="${escHtml(t.url)}"  />
      <label>
        <input type="radio" name="defaultTarget" value="${i}" ${t.isDefault ? "checked" : ""} />
        Default
      </label>
    `;
    container.appendChild(row);
  });
}

function collectTargets() {
  const rows   = document.querySelectorAll(".target-row");
  const defVal = parseInt(document.querySelector("input[name='defaultTarget']:checked")?.value ?? "0", 10);
  return Array.from(rows).map((row, i) => ({
    name:      row.querySelector(".t-name").value.trim(),
    url:       row.querySelector(".t-url").value.trim(),
    isDefault: i === defVal
  }));
}

// ── DOMContentLoaded ──────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {

  // Load all settings
  chrome.storage.local.get(
    [STORAGE_KEY, PROMPT_KEY, VENDOR_KEY, EXCLUSIONS_KEY, BEHAVIOR_KEY],
    (result) => {
      // Click behavior
      const behavior = result[BEHAVIOR_KEY] || DEFAULT_BEHAVIOR;
      const radio = document.querySelector(`input[name='clickBehavior'][value='${behavior}']`);
      if (radio) radio.checked = true;
      updateBehaviorHighlight();

      // AI targets
      buildRows(result[STORAGE_KEY] || DEFAULT_TARGETS);

      // Prompt context
      const p = result[PROMPT_KEY]  || DEFAULT_PROMPT;
      const v = result[VENDOR_KEY]  || DEFAULT_VENDORS;
      document.getElementById("promptTerms").value     = p.terms;
      document.getElementById("promptEnabled").checked = p.enabled;
      document.getElementById("vendorTerms").value     = v.terms;
      document.getElementById("vendorEnabled").checked = v.enabled;

      // Exclusions
      document.getElementById("exclusionsList").value = result[EXCLUSIONS_KEY] ?? DEFAULT_EXCLUSIONS;

      updatePreview();
    }
  );

  // Live preview
  ["promptTerms", "promptEnabled", "vendorTerms", "vendorEnabled"].forEach(id =>
    document.getElementById(id).addEventListener("input", updatePreview));
  ["promptEnabled", "vendorEnabled"].forEach(id =>
    document.getElementById(id).addEventListener("change", updatePreview));

  // Behavior card highlight on change
  document.querySelectorAll("input[name='clickBehavior']").forEach(radio =>
    radio.addEventListener("change", updateBehaviorHighlight));

  // Save
  document.getElementById("saveBtn").addEventListener("click", () => {
    const targets = collectTargets();
    if (!targets.some(t => t.isDefault)) targets[0].isDefault = true;

    const behavior   = document.querySelector("input[name='clickBehavior']:checked")?.value || DEFAULT_BEHAVIOR;
    const prompt     = { terms: document.getElementById("promptTerms").value.trim(),  enabled: document.getElementById("promptEnabled").checked };
    const vendors    = { terms: document.getElementById("vendorTerms").value.trim(),  enabled: document.getElementById("vendorEnabled").checked };
    const exclusions = document.getElementById("exclusionsList").value;

    chrome.storage.local.set({
      [STORAGE_KEY]:    targets,
      [PROMPT_KEY]:     prompt,
      [VENDOR_KEY]:     vendors,
      [EXCLUSIONS_KEY]: exclusions,
      [BEHAVIOR_KEY]:   behavior
    }, showSaved);
  });

  // Reset
  document.getElementById("resetBtn").addEventListener("click", () => {
    if (confirm("Reset all settings to defaults?")) {
      chrome.storage.local.set({
        [STORAGE_KEY]:    DEFAULT_TARGETS,
        [PROMPT_KEY]:     DEFAULT_PROMPT,
        [VENDOR_KEY]:     DEFAULT_VENDORS,
        [EXCLUSIONS_KEY]: DEFAULT_EXCLUSIONS,
        [BEHAVIOR_KEY]:   DEFAULT_BEHAVIOR
      }, () => {
        buildRows(DEFAULT_TARGETS);
        document.getElementById("promptTerms").value     = DEFAULT_PROMPT.terms;
        document.getElementById("promptEnabled").checked  = DEFAULT_PROMPT.enabled;
        document.getElementById("vendorTerms").value     = DEFAULT_VENDORS.terms;
        document.getElementById("vendorEnabled").checked  = DEFAULT_VENDORS.enabled;
        document.getElementById("exclusionsList").value  = DEFAULT_EXCLUSIONS;
        const radio = document.querySelector(`input[name='clickBehavior'][value='${DEFAULT_BEHAVIOR}']`);
        if (radio) radio.checked = true;
        updateBehaviorHighlight();
        updatePreview();
        showSaved();
      });
    }
  });

});
