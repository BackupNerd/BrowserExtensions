/**
 * Cove Error Search Links — Content Script v2.2
 * Runs on: https://device-properties.backup.management/*
 *
 * Two modes (controlled by Settings → Click Behavior):
 *   A — "icons"  : inject [AI] [Docs] [KB] pill buttons after each error text
 *   B — "single" : style error text as a blue link, click opens default AI search
 *
 * Settings loaded from chrome.storage.local (same keys as CDP Error Troubleshooter):
 *   aiTargets, aiPrompt, aiVendors, aiExclusions, clickBehavior
 *
 * Selector chain:
 *   tr.dx-data-row  →  span.copy-to-clipboard  →  span.apx-truncate
 *
 * Uses MutationObserver to handle the virtualized list (rows render on scroll).
 * No existing DOM nodes are moved or restructured.
 */

'use strict';

console.log('[CoveErrorLinks] v2.2 content script loaded on', location.href);
window.__coveLoaded = true;

// ── Constants ──────────────────────────────────────────────────────────────
const STYLED_ATTR = 'data-cove-error-linked';

// ── Window management ────────────────────────────────────────────────────
// Always call window.open with the SAME named target ('CoveSearchWindow').
// Chrome/Edge: first call spawns a new popup window; subsequent calls with
// the same name navigate that existing window instead of opening a new one.
// The 'popup' feature word is what forces a window rather than a tab.
function openSearchUrl(url) {
  const w = window.open(url, 'CoveSearchWindow', 'popup,width=1280,height=900,left=120,top=80');
  if (w) w.focus();
}

// ── Runtime settings (overwritten from storage on init) ───────────────────
let _clickBehavior = 'icons'; // 'icons' (A) | 'single' (B)
let _aiTargetUrl   = 'https://www.google.com/search?q=';
let _aiPrompt      = { terms: 'Troubleshoot Cove Data Protection with the following error.', enabled: true };
let _aiVendors     = { terms: 'Find similar resolution for third party backup products like Veeam, Acronis and others.', enabled: true };
let _aiExclusions  = 'withcove.com';

// ── Known error database (docs + KB links) ────────────────────────────────
const ERROR_DB = {
  'access is denied': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/access-denied.htm'
  },
  'the system cannot find the file specified': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/file-not-found.htm'
  },
  'client was restarted during backup': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/client-restarted.htm'
  },
  'failed to send some of the file': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/storage-upload-failed.htm'
  },
  'process cannot access the file because it is being used': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/file-in-use.htm'
  },
  'operation was aborted': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/operation-aborted.htm'
  },
  'no data available for the backup': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/no-data.htm'
  },
  'failed to open/read local data from fileapplication': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/fileapplication-error.htm'
  },
  'cannot connect to backup register': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/connectivity.htm'
  },
  'transfer aborted by user': {
  },
  'full disk access is not granted': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/macos-full-disk-access.htm'
  },
  'operation not permitted': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/macos-full-disk-access.htm'
  },
  'error while listing directory content': {
    docs: 'https://documentation.n-able.com/covedataprotection/userguide/documentation/Content/backup-manager/backup-errors/directory-listing-error.htm'
  }
};

// ── URL builders ──────────────────────────────────────────────────────────
function norm(s) {
  return (s || '').toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').trim();
}

function lookupError(text) {
  const lower = norm(text);
  for (const key in ERROR_DB) {
    if (lower.includes(key)) return ERROR_DB[key];
  }
  return null;
}

function buildExclusionSuffix() {
  if (!_aiExclusions) return '';
  return _aiExclusions.split('\n')
    .map(t => t.trim()).filter(Boolean)
    .map(t => '-site:' + t.replace(/^https?:\/\//i, '').replace(/\/$/, ''))
    .join(' ');
}

function buildAiSearchUrl(text) {
  const base  = _aiTargetUrl || 'https://www.google.com/search?q=';
  const parts = [];
  if (_aiPrompt.enabled  && _aiPrompt.terms)  parts.push(_aiPrompt.terms);
  parts.push(text);
  if (_aiVendors.enabled && _aiVendors.terms) parts.push(_aiVendors.terms);
  const suffix = buildExclusionSuffix();
  if (suffix) parts.push(suffix);
  let url = base + encodeURIComponent(parts.join(' '));
  // Ensure Google AI Mode is activated (?q=...&udm=50) unless already present
  if (base.includes('google.com/search') && !url.includes('udm=50')) url += '&udm=50';
  return url;
}

function buildDocsSearchUrl(text) {
  return 'https://documentation.n-able.com/covedataprotection/USERGUIDE/documentation/Content/Search.htm?q=' + encodeURIComponent(text);
}

function buildKbSearchUrl(text) {
  return 'https://me.n-able.com/s/global-search/%40uri#q='
    + encodeURIComponent(text)
    + '&t=All&sort=relevancy&f:@category=[Cove%20Data%20Protection]';
}

// ── Option A: inject [AI] [Docs] [KB] icon buttons ────────────────────────
// Appends a span.cove-icon-row to span.copy-to-clipboard — no existing nodes moved.
function injectIcons(span) {
  if (span.hasAttribute(STYLED_ATTR)) return;
  const errorText = span.textContent.trim();
  if (!errorText || errorText.length < 3) return;
  span.setAttribute(STYLED_ATTR, 'true');

  const container = span.parentElement; // span.copy-to-clipboard
  if (!container || container.querySelector('.cove-icon-row')) return;

  const entry   = lookupError(errorText);
  const iconRow = document.createElement('span');
  iconRow.className = 'cove-icon-row';

  const buttons = [
    { cls: 'cove-ai',   label: 'AI',   title: 'Search with AI',           url: () => buildAiSearchUrl(errorText) },
    { cls: 'cove-docs', label: 'Docs', title: 'Open Documentation',       url: () => (entry && entry.docs) ? entry.docs : buildDocsSearchUrl(errorText) },
    { cls: 'cove-kb',   label: 'KB',   title: 'Open Knowledge Base',      url: () => (entry && entry.kb)   ? entry.kb   : buildKbSearchUrl(errorText)  },
  ];

  buttons.forEach(function(b) {
    const btn = document.createElement('button');
    btn.className   = 'cove-icon-btn ' + b.cls;
    btn.textContent = b.label;
    btn.title       = b.title;
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      openSearchUrl(b.url());
    });
    iconRow.appendChild(btn);
  });

  container.appendChild(iconRow);
}

// ── Option B: style error text as single blue clickable link ──────────────
function styleAsLink(span) {
  if (span.hasAttribute(STYLED_ATTR)) return;
  const errorText = span.textContent.trim();
  if (!errorText || errorText.length < 3) return;
  span.setAttribute(STYLED_ATTR, 'true');
  span.title = 'Click to search: "' + errorText + '"';
}

// Event delegation for Option B — capture phase fires before DevExtreme handlers
document.addEventListener('click', function(e) {
  if (_clickBehavior !== 'single') return;
  const span = e.target.closest('span.apx-truncate[' + STYLED_ATTR + ']');
  if (!span) return;
  e.preventDefault();
  e.stopPropagation();
  openSearchUrl(buildAiSearchUrl(span.textContent.trim()));
}, true);

// ── Main process function (device-properties DevExtreme grid) ───────────
function processVisibleErrors() {
  const selector = 'tr.dx-data-row span.copy-to-clipboard span.apx-truncate:not([' + STYLED_ATTR + '])';
  const handler  = _clickBehavior === 'single' ? styleAsLink : injectIcons;
  document.querySelectorAll(selector).forEach(handler);
}

// ── Alt-page processor (*.cloudbackup.management / localhost:5000) ────────
// Structure confirmed by CDP inspection:
//   Modal:       #detailsErrorDialog  (class gets "in" added when open)
//   Data table:  table.table-striped.table-bordered  (no header row, column 2 = Error)
//   Header table: table.mb0 (separate element, skipped by .table-striped selector)
// Also handles #detailsErrorDialogReport (same structure, different modal).
const ALT_ROW_ATTR    = 'data-cove-row-processed';
const ALT_CELL_SEL    = '.modal.in table.table-striped tr:not([' + ALT_ROW_ATTR + ']) td:nth-child(2)';

function processAltErrors() {
  document.querySelectorAll(ALT_CELL_SEL).forEach(function(errorCell) {
    const errorText = errorCell.textContent.trim();
    if (!errorText || errorText.length < 5) return;
    if (/^[\d,]+$/.test(errorText)) return; // skip pure-number cells
    const row = errorCell.closest('tr');
    row.setAttribute(ALT_ROW_ATTR, 'true');
    if (_clickBehavior === 'single') {
      styleAltCell(errorCell, errorText);
    } else {
      injectAltIcons(errorCell, errorText);
    }
  });
}

function injectAltIcons(cell, errorText) {
  if (cell.querySelector('.cove-icon-row')) return;
  const entry   = lookupError(errorText);
  const iconRow = document.createElement('span');
  iconRow.className = 'cove-icon-row';

  const buttons = [
    { cls: 'cove-ai',   label: 'AI',   title: 'Search with AI',      url: function() { return buildAiSearchUrl(errorText); } },
    { cls: 'cove-docs', label: 'Docs', title: 'Open Documentation',  url: function() { return (entry && entry.docs) ? entry.docs : buildDocsSearchUrl(errorText); } },
    { cls: 'cove-kb',   label: 'KB',   title: 'Open Knowledge Base', url: function() { return (entry && entry.kb)   ? entry.kb   : buildKbSearchUrl(errorText);  } },
  ];
  buttons.forEach(function(b) {
    const btn = document.createElement('button');
    btn.className   = 'cove-icon-btn ' + b.cls;
    btn.textContent = b.label;
    btn.title       = b.title;
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      openSearchUrl(b.url());
    });
    iconRow.appendChild(btn);
  });
  cell.appendChild(iconRow);
}

function styleAltCell(cell, errorText) {
  cell.setAttribute(STYLED_ATTR, 'true');
  cell.title = 'Click to search: "' + errorText + '"';
  cell.addEventListener('click', function(e) {
    e.stopPropagation();
    e.preventDefault();
    openSearchUrl(buildAiSearchUrl(errorText));
  }, true);
}

function startAltObserver() {
  console.log('[CoveErrorLinks] Alt-page mode active on', location.hostname);
  processAltErrors();
  new MutationObserver(function(mutations) {
    var relevant = mutations.some(function(m) {
      return m.addedNodes.length > 0 || m.type === 'attributes';
    });
    if (relevant) processAltErrors();
  }).observe(document.body, {
    childList:       true,
    subtree:         true,
    attributes:      true,        // fires when modal gains/loses "in" class
    attributeFilter: ['class']
  });
}

// ── Wait for virtualised grid ─────────────────────────────────────────────
function waitForGrid(callback, attempts) {
  attempts = attempts || 0;
  if (document.querySelectorAll('tr.dx-data-row').length > 0) {
    console.log('[CoveErrorLinks] Grid ready. Mode:', _clickBehavior);
    callback();
  } else if (attempts < 40) {
    setTimeout(function() { waitForGrid(callback, attempts + 1); }, 250);
  } else {
    console.warn('[CoveErrorLinks] Grid never appeared after 10s.');
  }
}

// ── Load settings then initialise ────────────────────────────────────────
function applySettings(s) {
  if (s.clickBehavior) _clickBehavior = s.clickBehavior;
  const targets = s.aiTargets;
  if (Array.isArray(targets)) {
    const def = targets.find(function(t) { return t.isDefault && t.url; }) || targets.find(function(t) { return t.url; });
    if (def) _aiTargetUrl = def.url;
  }
  if (s.aiPrompt)           _aiPrompt     = s.aiPrompt;
  if (s.aiVendors)          _aiVendors    = s.aiVendors;
  if (s.aiExclusions != null) _aiExclusions = s.aiExclusions;
}

function startObserver() {
  processVisibleErrors();
  const observer = new MutationObserver(function(mutations) {
    if (mutations.some(function(m) { return m.addedNodes.length > 0; })) {
      processVisibleErrors();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function init() {
  const isDevProps = location.hostname === 'device-properties.backup.management';
  const startFn   = isDevProps ? function() { waitForGrid(startObserver); } : startAltObserver;
  try {
    chrome.storage.local.get(
      ['clickBehavior', 'aiTargets', 'aiPrompt', 'aiVendors', 'aiExclusions'],
      function(s) {
        applySettings(s || {});
        startFn();
      }
    );
  } catch (e) {
    console.warn('[CoveErrorLinks] storage unavailable, using defaults.', e);
    startFn();
  }
}

init();
